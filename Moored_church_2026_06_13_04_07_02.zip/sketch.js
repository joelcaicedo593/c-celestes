let page = 1;
let stars = [];
let comets = [];
let floatingTexts = [];

let transitionAlpha = 0;
let isTransitioning = false;

let phrases = [
  "Toda estrella brilla por mas pequeña que sea.",
  "Los cometas pasan en los momentos menos esperados.",
  "Viajar solo no es equivalente a sentirlo.",
  "Los mejores momentos pueden ser fugaces.",
  "Un saludo desde otro mundo o espacio puede ser confortante.",
  "No intentes brillar en un espacio cual no es de tu agrado.",
  "No todo choque de cometas son catastróficos.",
  "La belleza de la luz es apreciarla y la oscuridad es que nunca te deja de lado.",
  "A donde vayas siempre habra un nuevo mundo que explorar."
];

function setup() {
  createCanvas(600, 600);
  noStroke();
  for (let i = 0; i < 40; i++) {
    stars.push(new PixelStar());
  }
}

function draw() {
  if (page === 1) {
    drawPage1();
  } else if (page === 2) {
    drawPage2();
  }

  if (isTransitioning) {
    transitionAlpha += 15;
    fill(255, 255, 255, transitionAlpha);
    rect(0, 0, width, height);
    if (transitionAlpha >= 255) {
      page = 2;
      isTransitioning = false;
    }
  } else if (transitionAlpha > 0) {
    transitionAlpha -= 10;
    fill(255, 255, 255, transitionAlpha);
    rect(0, 0, width, height);
  }
}

function drawPage1() {
  background('#00008B');
  fill('#C0C0C0');
  textAlign(CENTER, CENTER);
  textSize(22);
  textFont('Courier New');
  text("Hora de conocer los cuerpos celestes", width / 2, height / 2);
  textSize(12);
  fill(192, 192, 192, 150);
  text("(Haz click para continuar)", width / 2, height / 2 + 50);
}

function drawPage2() {
  background(10, 10, 25);
  for (let star of stars) {
    star.update();
    star.display();
  }
  if (random(1) < 0.01 && comets.length < 3) {
    comets.push(new PixelComet());
  }
  for (let i = comets.length - 1; i >= 0; i--) {
    comets[i].update();
    comets[i].display();
    if (comets[i].isOffScreen()) comets.splice(i, 1);
  }
  for (let i = floatingTexts.length - 1; i >= 0; i--) {
    floatingTexts[i].update();
    floatingTexts[i].display();
    if (floatingTexts[i].isDead()) floatingTexts.splice(i, 1);
  }
}

function mousePressed() {
  if (page === 1 && !isTransitioning) isTransitioning = true;
  else if (page === 2) {
    for (let i = comets.length - 1; i >= 0; i--) {
      if (comets[i].checkClick(mouseX, mouseY)) {
        floatingTexts.push(new FloatingText(mouseX, mouseY, random(phrases)));
        comets.splice(i, 1);
        break;
      }
    }
  }
}

class PixelStar {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.size = random([2, 4, 6]);
    this.speed = this.size * 0.15;
  }
  update() {
    this.y += this.speed;
    if (this.y > height) { this.y = 0; this.x = random(width); }
  }
  display() { fill(200, 200, 255); rect(this.x, this.y, this.size, this.size); }
}

class PixelComet {
  constructor() {
    this.x = -60;
    this.y = random(50, height - 150);
    this.speed = random(0.6, 1.2);
    this.pixelSize = 12; // Increased from 5 to 12 to make the comet head and trail larger
    this.trail = []; 
  }

  update() {
    this.x += this.speed;
    this.trail.push({x: this.x, y: this.y});
    if (this.trail.length > 12) this.trail.shift(); // Slightly longer trail storage
  }

  display() {
    // Draw scaled white trail
    for(let i = 0; i < this.trail.length; i++) {
      let alpha = map(i, 0, this.trail.length, 0, 200);
      fill(255, 255, 255, alpha);
      rect(this.trail[i].x, this.trail[i].y, this.pixelSize, this.pixelSize);
    }
    // Draw Bigger Comet Head
    fill(255, 255, 255);
    rect(this.x, this.y, this.pixelSize, this.pixelSize);
  }

  isOffScreen() { return this.x > width + 60; }

  checkClick(mx, my) {
    // Hitbox scales perfectly with the new pixelSize configuration
    return (mx >= this.x && mx <= this.x + this.pixelSize && my >= this.y && my <= this.y + this.pixelSize);
  }
}

class FloatingText {
  constructor(x, y, message) {
    this.x = x; this.y = y; this.message = message; this.alpha = 255; this.speedY = -0.4;
  }
  update() { this.y += this.speedY; this.alpha -= 1.2; }
  display() {
    push();
    textAlign(CENTER, BOTTOM);
    textFont('Courier New');
    textSize(13);
    
    // Drop shadow for better readability over the larger trails
    fill(0, 0, 0, this.alpha);
    text(this.message, this.x + 1, this.y - 10 + 1);
    
    fill(255, 255, 255, this.alpha);
    text(this.message, this.x, this.y - 10);
    pop();
  }
  isDead() { return this.alpha <= 0; }
}